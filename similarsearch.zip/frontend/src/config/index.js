import Config from './config.json'

export default {
    apiEndpoint: Config.apiEndpoint
};